// module.exports={
//     name:"张三",
//     age:20
// }
// exports.name = "张三";
// exports.age = 20;

// exports = {
//         name:"张三",
//         age:20
//     }
// npm i 模块名称； -g;