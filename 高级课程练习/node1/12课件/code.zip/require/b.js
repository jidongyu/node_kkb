console.log("b.js文件...")
define({
    name:"b的名字",
    height:"178cm"
});