require("./a.js");
console.log("我是测试上传到npm服务器的文件");
// cnpm  
// npm --->源 改成  https://registry.npm.taobao.org/
// 包管理器 是 npm
// nvm是管理node版本的；